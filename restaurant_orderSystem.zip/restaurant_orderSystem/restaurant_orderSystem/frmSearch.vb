﻿

Imports MySql.Data.MySqlClient

Public Class frmSearch
    Dim MySqlConnetion As New MySqlConnection("host=127.001;user=root;database=OrderingSystem;")
    Dim con As MySqlConnection
    Public category As String
    Public searchOptions As String
    Private Sub frmMain_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            MySqlConnetion.Open()
            MessageBox.Show("successfully connected")
        Catch ex As Exception
            MessageBox.Show(ex.Message)

        End Try

    End Sub


    Private Sub LoadSearchOptions()
        cboSearch.Items.Clear()
        If category = "Menu Item" Then
            cboSearch.Items.AddRange({"Name", "ID"})
        ElseIf category = "Customer" Then
            cboSearch.Items.AddRange({"Name", "ID"})
        End If
    End Sub

    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click
        If Not String.IsNullOrEmpty(txtKeyword.Text) Then
            Dim query As String = ""
            If category = "Menu Item" Then
                If searchOptions = "Name" Then
                    query = "SELECT * FROM Menu WHERE Name LIKE '%" & txtKeyword.Text & "%'"
                ElseIf searchOptions = "ID" Then
                    query = "SELECT * FROM Menu WHERE ID = " & txtKeyword.Text
                End If
            ElseIf category = "Customer" Then
                If searchOptions = "Name" Then
                    query = "SELECT * FROM Customers WHERE Name LIKE '%" & txtKeyword.Text & "%'"
                ElseIf searchOptions = "ID" Then
                    query = "SELECT * FROM Customers WHERE ID = " & txtKeyword.Text
                End If
            End If

            Dim cmd As New MySqlCommand(query, con)
            Dim dr As MySqlDataReader = cmd.ExecuteReader()
            dgvSearch.Rows.Clear()
            While dr.Read()
                Dim row As DataGridViewRow = New DataGridViewRow()
                row.CreateCells(dgvSearch)
                For i As Integer = 0 To dr.FieldCount - 1
                    row.Cells(i).Value = dr(i)
                Next
                dgvSearch.Rows.Add(row)
            End While
            dr.Close()
        Else
            MessageBox.Show("Please enter a keyword to search.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
    End Sub

    Private Sub dgvSearch_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvSearch.CellContentClick

    End Sub
End Class
