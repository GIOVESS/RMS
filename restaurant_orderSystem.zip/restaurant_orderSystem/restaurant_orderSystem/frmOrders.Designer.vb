﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmOrders
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Label1 = New Label()
        Label2 = New Label()
        Button1 = New Button()
        orderBox = New ListBox()
        SuspendLayout()
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.BackColor = Color.Black
        Label1.Font = New Font("Sitka Heading", 15F)
        Label1.ForeColor = Color.White
        Label1.Location = New Point(263, 23)
        Label1.Name = "Label1"
        Label1.Size = New Size(194, 29)
        Label1.TabIndex = 0
        Label1.Text = "ROYAL RESTAURANT"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.BackColor = Color.Black
        Label2.Font = New Font("Sitka Small", 12F)
        Label2.ForeColor = Color.White
        Label2.Location = New Point(12, 68)
        Label2.Name = "Label2"
        Label2.Size = New Size(147, 24)
        Label2.TabIndex = 1
        Label2.Text = "ORDERS PLACED"
        ' 
        ' Button1
        ' 
        Button1.BackColor = Color.Black
        Button1.Cursor = Cursors.Hand
        Button1.Font = New Font("Sitka Small", 10F)
        Button1.ForeColor = Color.White
        Button1.Location = New Point(596, 397)
        Button1.Name = "Button1"
        Button1.Size = New Size(122, 41)
        Button1.TabIndex = 2
        Button1.Text = "EXIT"
        Button1.UseVisualStyleBackColor = False
        ' 
        ' orderBox
        ' 
        orderBox.FormattingEnabled = True
        orderBox.ItemHeight = 15
        orderBox.Location = New Point(82, 109)
        orderBox.Name = "orderBox"
        orderBox.Size = New Size(484, 259)
        orderBox.TabIndex = 3
        ' 
        ' frmOrders
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackgroundImage = My.Resources.Resources.back
        ClientSize = New Size(800, 450)
        Controls.Add(orderBox)
        Controls.Add(Button1)
        Controls.Add(Label2)
        Controls.Add(Label1)
        FormBorderStyle = FormBorderStyle.None
        Name = "frmOrders"
        Text = "frmOrders"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Button1 As Button
    Friend WithEvents orderBox As ListBox
End Class
