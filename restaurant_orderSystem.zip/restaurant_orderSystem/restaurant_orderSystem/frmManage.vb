﻿Imports MySql.Data.MySqlClient
Imports Windows.Win32.System

Public Class frmManage
    Dim MySqlConnection As New MySqlConnection("host=127.001;user=root;database=OrderingSystem;")
    Dim con As MySqlConnection
    Private Sub frmMain_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            MySqlConnection.Open()
            MessageBox.Show("Successfully connected")
            MySqlConnection.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
        startMenu()
    End Sub
    Public Sub startMenu()
        Try
            menuBox.Items.Clear()
            con.Open()
            Dim query As String = "SELECT Name, Price FROM menu"
            Dim cmd As New MySqlCommand(query, con)
            Dim dr As MySqlDataReader = cmd.ExecuteReader()
            While dr.Read()
                Dim item As String = dr("Name") & " - $" & dr("Price")
                menuBox.Items.Add(item)
            End While
            dr.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            con.Close()
        End Try
    End Sub
    Private Sub btnFoodAdd_Click(sender As Object, e As EventArgs) Handles btnFoodAdd.Click
        Try
            MySqlConnection.Open()
            Dim query As String = "INSERT INTO menu (Id, Name, Price) VALUES (@Id, @Name, @Price)"
            Dim cmd As New MySqlCommand(query, MySqlConnection)
            cmd.Parameters.AddWithValue("@Id", txtId.Text)
            cmd.Parameters.AddWithValue("@Name", txtName.Text)
            cmd.Parameters.AddWithValue("@Price", txtPrice.Text)
            cmd.ExecuteNonQuery()
            MessageBox.Show("Data sent successfully")

            Dim displayForm As New frmMain()
            displayForm.RefreshMenu()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            MySqlConnection.Close()
        End Try
    End Sub

    Private Sub btnLogout_Click(sender As Object, e As EventArgs) Handles btnLogout.Click
        Me.Close()
        frmLogin.Show()
    End Sub
End Class
