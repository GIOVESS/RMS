﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmManage
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Label1 = New Label()
        Label2 = New Label()
        lblFoodId = New Label()
        lblFoodName = New Label()
        lblFoodPrice = New Label()
        txtId = New TextBox()
        txtName = New TextBox()
        txtPrice = New TextBox()
        btnFoodAdd = New Button()
        menuBox = New ListBox()
        btnLogout = New Button()
        SuspendLayout()
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.BackColor = Color.Black
        Label1.FlatStyle = FlatStyle.Flat
        Label1.Font = New Font("Sitka Small", 14.25F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label1.ForeColor = Color.White
        Label1.Location = New Point(281, 34)
        Label1.Name = "Label1"
        Label1.Size = New Size(168, 28)
        Label1.TabIndex = 0
        Label1.Text = "MANAGE ITEMS"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.BackColor = Color.Black
        Label2.Font = New Font("Sitka Small", 9.75F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label2.ForeColor = Color.White
        Label2.Location = New Point(73, 77)
        Label2.Name = "Label2"
        Label2.Size = New Size(134, 19)
        Label2.TabIndex = 1
        Label2.Text = "ENTER NEW ITEM"
        ' 
        ' lblFoodId
        ' 
        lblFoodId.AutoSize = True
        lblFoodId.BackColor = Color.Black
        lblFoodId.Font = New Font("Sitka Small", 9F)
        lblFoodId.ForeColor = Color.White
        lblFoodId.Location = New Point(73, 117)
        lblFoodId.Name = "lblFoodId"
        lblFoodId.Size = New Size(60, 18)
        lblFoodId.TabIndex = 2
        lblFoodId.Text = "FOOD ID"
        ' 
        ' lblFoodName
        ' 
        lblFoodName.AutoSize = True
        lblFoodName.BackColor = Color.Black
        lblFoodName.Font = New Font("Sitka Small", 9F)
        lblFoodName.ForeColor = Color.White
        lblFoodName.Location = New Point(72, 182)
        lblFoodName.Name = "lblFoodName"
        lblFoodName.Size = New Size(84, 18)
        lblFoodName.TabIndex = 3
        lblFoodName.Text = "FOOD NAME"
        ' 
        ' lblFoodPrice
        ' 
        lblFoodPrice.AutoSize = True
        lblFoodPrice.BackColor = Color.Black
        lblFoodPrice.Font = New Font("Sitka Small", 9F)
        lblFoodPrice.ForeColor = Color.White
        lblFoodPrice.Location = New Point(72, 245)
        lblFoodPrice.Name = "lblFoodPrice"
        lblFoodPrice.Size = New Size(83, 18)
        lblFoodPrice.TabIndex = 4
        lblFoodPrice.Text = "FOOD PRICE"
        ' 
        ' txtId
        ' 
        txtId.Location = New Point(186, 117)
        txtId.Name = "txtId"
        txtId.Size = New Size(175, 23)
        txtId.TabIndex = 5
        ' 
        ' txtName
        ' 
        txtName.Location = New Point(186, 177)
        txtName.Name = "txtName"
        txtName.Size = New Size(175, 23)
        txtName.TabIndex = 6
        ' 
        ' txtPrice
        ' 
        txtPrice.Location = New Point(186, 231)
        txtPrice.Name = "txtPrice"
        txtPrice.Size = New Size(175, 23)
        txtPrice.TabIndex = 7
        ' 
        ' btnFoodAdd
        ' 
        btnFoodAdd.BackColor = Color.Black
        btnFoodAdd.Font = New Font("Sitka Small", 10F)
        btnFoodAdd.ForeColor = Color.White
        btnFoodAdd.Location = New Point(72, 297)
        btnFoodAdd.Name = "btnFoodAdd"
        btnFoodAdd.Size = New Size(140, 39)
        btnFoodAdd.TabIndex = 9
        btnFoodAdd.Text = "ADD ITEMS"
        btnFoodAdd.UseVisualStyleBackColor = False
        ' 
        ' menuBox
        ' 
        menuBox.FormattingEnabled = True
        menuBox.ItemHeight = 15
        menuBox.Location = New Point(452, 86)
        menuBox.Name = "menuBox"
        menuBox.Size = New Size(394, 289)
        menuBox.TabIndex = 10
        ' 
        ' btnLogout
        ' 
        btnLogout.BackColor = Color.Black
        btnLogout.Font = New Font("Sitka Small", 10F)
        btnLogout.ForeColor = Color.White
        btnLogout.Location = New Point(12, 406)
        btnLogout.Name = "btnLogout"
        btnLogout.Size = New Size(143, 32)
        btnLogout.TabIndex = 11
        btnLogout.Text = "LOG OUT"
        btnLogout.UseVisualStyleBackColor = False
        ' 
        ' frmManage
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackgroundImage = My.Resources.Resources.back
        ClientSize = New Size(889, 450)
        Controls.Add(btnLogout)
        Controls.Add(menuBox)
        Controls.Add(btnFoodAdd)
        Controls.Add(txtPrice)
        Controls.Add(txtName)
        Controls.Add(txtId)
        Controls.Add(lblFoodPrice)
        Controls.Add(lblFoodName)
        Controls.Add(lblFoodId)
        Controls.Add(Label2)
        Controls.Add(Label1)
        FormBorderStyle = FormBorderStyle.None
        Name = "frmManage"
        Text = "frmManage"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents lblFoodId As Label
    Friend WithEvents lblFoodName As Label
    Friend WithEvents lblFoodPrice As Label
    Friend WithEvents txtId As TextBox
    Friend WithEvents txtName As TextBox
    Friend WithEvents txtPrice As TextBox
    Friend WithEvents btnFoodAdd As Button
    Friend WithEvents menuBox As ListBox
    Friend WithEvents btnLogout As Button
End Class
