﻿Imports MySql.Data.MySqlClient
Imports Windows.Win32.System

Public Class frmOrders
    Dim MySqlConnection As New MySqlConnection("host=127.001;user=root;database=OrderingSystem;")
    Dim con As MySqlConnection
    Dim total As Double
    Private Sub frmMain_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            con = New MySqlConnection(MySqlConnection.ConnectionString)
            MySqlConnection.Open()
            MessageBox.Show("successfully connected")
        Catch ex As Exception
            MessageBox.Show(ex.Message)

        End Try
        RefreshOrder()
    End Sub
    Public Sub RefreshOrder()
        Try
            orderBox.Items.Clear()
            con.Open()
            Dim query As String = "SELECT Name, Price, Quantity FROM Orders"
            Dim cmd As New MySqlCommand(query, con)
            Dim dr As MySqlDataReader = cmd.ExecuteReader()
            While dr.Read()
                Dim item As String = dr("Name") & " - $" & dr("Price") & " -$" & dr("Quantity")
                orderBox.Items.Add(item)
            End While
            dr.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            con.Close()
        End Try
    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()
        frmLogin.Show()
    End Sub
End Class