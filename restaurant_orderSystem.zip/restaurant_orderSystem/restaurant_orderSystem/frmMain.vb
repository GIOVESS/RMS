﻿
Imports System.Drawing.Printing
Imports MySql.Data.MySqlClient

Public Class frmMain
    Dim MySqlConnection As New MySqlConnection("host=127.001;user=root;database=OrderingSystem;")
    Dim con As MySqlConnection
    Dim total As Double
    Private Sub frmMain_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            con = New MySqlConnection(MySqlConnection.ConnectionString)
            MySqlConnection.Open()
            MessageBox.Show("successfully connected")
        Catch ex As Exception
            MessageBox.Show(ex.Message)

        End Try
        RefreshMenu()

    End Sub
    Public Sub RefreshMenu()
        Try
            lstMenu.Items.Clear()
            con.Open()
            Dim query As String = "SELECT Name, Price FROM menu"
            Dim cmd As New MySqlCommand(query, con)
            Dim dr As MySqlDataReader = cmd.ExecuteReader()
            While dr.Read()
                Dim item As String = dr("Name") & " - $" & dr("Price")
                lstMenu.Items.Add(item)
            End While
            dr.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            con.Close()
        End Try
    End Sub



    Private Sub CalculateTotal()
        total = 0
        For Each item As String In lstOrder.Items
            Dim arr() As String = item.Split(" ")
            Dim quantity As Integer = CInt(arr(0))
            Dim price As Double = CDbl(arr(2))
            total += quantity * price
        Next
        txtTotal.Text = total.ToString("0.00")
    End Sub

    Private Sub PrintReceipt()
        Dim pd As New PrintDocument()
        Dim pdlg As New PrintDialog()
        pdlg.Document = pd
        If pdlg.ShowDialog() = DialogResult.OK Then
            AddHandler pd.PrintPage, AddressOf pd_PrintPage
            pd.Print()
        End If
    End Sub

    Private Sub pd_PrintPage(sender As Object, e As PrintPageEventArgs)
        Dim g As Graphics = e.Graphics
        Dim font As New Font("Arial", 12)
        Dim brush As New SolidBrush(Color.Black)
        Dim sf As New StringFormat()
        sf.Alignment = StringAlignment.Center
        Dim rect As New Rectangle(0, 0, e.PageBounds.Width, e.PageBounds.Height)
        Dim receipt As String = "Restaurant Ordering System" & vbCrLf &
                                    "----------------------------------------" & vbCrLf &
                                    "Order Details" & vbCrLf &
                                    "----------------------------------------" & vbCrLf

        For Each item As String In lstOrder.Items
            receipt &= item & vbCrLf
        Next

        receipt &= "----------------------------------------" & vbCrLf &
                       "Total: $" & txtTotal.Text & vbCrLf &
                       "----------------------------------------" & vbCrLf &
                       "Thank you for ordering!" & vbCrLf &
                       "Welcome!"

        g.DrawString(receipt, font, brush, rect, sf)
    End Sub

    Private Sub lstMenu_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lstMenu.SelectedIndexChanged
        If lstMenu.SelectedIndex >= 0 Then
            Dim item As String = lstMenu.SelectedItem
            Dim arr() As String = item.Split("-")
            Dim name As String = arr(0).Trim()
            Dim price As String = arr(1).Trim()
            Dim order As String = "1 " & name & " " & price
            lstOrder.Items.Add(order)
            txtQuantity.Text = "1"
            Try
                Dim connectionString As String = "host=127.001;user=root;database=OrderingSystem;"
                Using connection As New MySqlConnection(connectionString)
                    connection.Open()

                    Dim query As String = "INSERT INTO Orders (Quantity, Name, Price) VALUES (@Quantity, @Name, @Price)"
                    Using cmd As New MySqlCommand(query, MySqlConnection)
                        cmd.Parameters.AddWithValue("@Quantity", 1)
                        cmd.Parameters.AddWithValue("@Name", name)
                        cmd.Parameters.AddWithValue("@Price", price)
                        cmd.ExecuteNonQuery()
                    End Using
                End Using
            Catch ex As Exception
                MessageBox.Show("Error: " & ex.Message)

            End Try
        End If
    End Sub




    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        If lstMenu.SelectedIndex >= 0 Then
            Dim item As String = lstMenu.SelectedItem
            Dim arr() As String = item.Split("-")
            Dim name As String = arr(0).Trim()
            Dim price As String = arr(1).Trim()
            Dim quantity As Integer = CInt(txtQuantity.Text)
            Dim order As String = quantity & " " & name & " " & price
            lstOrder.Items.Add(order)
            CalculateTotal()
        Else
            MessageBox.Show("Please select a menu item first.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
    End Sub

    Private Sub btnRemove_Click(sender As Object, e As EventArgs) Handles btnRemove.Click
        If lstOrder.SelectedIndex >= 0 Then
            lstOrder.Items.RemoveAt(lstOrder.SelectedIndex)
            CalculateTotal()
        Else
            MessageBox.Show("Please select an order item first.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
    End Sub

    Private Sub btnPrint_Click(sender As Object, e As EventArgs) Handles btnPrint.Click
        PrintReceipt()
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        lstOrder.Items.Clear()
        txtTotal.Text = ""
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub lstOrder_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lstOrder.SelectedIndexChanged

    End Sub
End Class


